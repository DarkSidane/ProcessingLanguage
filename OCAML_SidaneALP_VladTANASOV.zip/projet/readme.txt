Homework made by Sidane ALP and Vlad TANASOV.
To execute the program please use the following command in the main folder:
dune exec main

